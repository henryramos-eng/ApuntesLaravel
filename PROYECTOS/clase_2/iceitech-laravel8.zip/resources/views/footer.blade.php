<div class="panel panel-default">
    <div class="panel-body">
        Wicked Awesome Website.
    </div>
    <div class="panel-footer">{{ $footer }}</div>
</div>