<div class="panel panel-default">
    <div class="panel-body">
        Wicked Awesome Website.
    </div>
    <div class="panel-footer"><?php echo e($footer); ?></div>
</div><?php /**PATH C:\laragon\www\iceitech-laravel8\resources\views/footer.blade.php ENDPATH**/ ?>