 
<?php $__env->startSection('content'); ?>
 
    <div class="jumbotron">
        <h1><?php echo e($variableone); ?></h1>
 
        <p><?php echo e($variabletwo); ?></p>
 
        <p><a class="btn btn-primary btn-lg" href="#" role="button"> <?php echo e($variablethree); ?></a></p>
    </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\iceitech-laravel8\resources\views/helloworld.blade.php ENDPATH**/ ?>